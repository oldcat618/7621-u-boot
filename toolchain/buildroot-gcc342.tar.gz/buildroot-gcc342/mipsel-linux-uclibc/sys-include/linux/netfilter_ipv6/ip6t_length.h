#ifndef _IP6T_LENGTH_H
#define _IP6T_LENGTH_H

struct ip6t_length_info {
	u_int16_t  min, max;
	u_int8_t   invert;
};

#endif /*_IP6T_LENGTH_H*/
	
