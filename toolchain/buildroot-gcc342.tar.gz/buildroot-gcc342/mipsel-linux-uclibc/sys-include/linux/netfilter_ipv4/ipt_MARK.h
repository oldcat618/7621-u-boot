#ifndef _IPT_MARK_H_target
#define _IPT_MARK_H_target

struct ipt_mark_target_info {
	unsigned long mark;
};

#endif /*_IPT_MARK_H_target*/
