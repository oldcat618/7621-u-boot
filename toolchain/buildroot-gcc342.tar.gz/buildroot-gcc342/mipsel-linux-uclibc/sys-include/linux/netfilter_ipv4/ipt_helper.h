#ifndef _IPT_HELPER_H
#define _IPT_HELPER_H

struct ipt_helper_info {
	int invert;
	char name[30];
};
#endif /* _IPT_HELPER_H */
